const AWS = require('aws-sdk')
/*import {DynamoDBClient} from "@aws-sdk/client-dynamodb";
import {DynamoDBDocumentClient, PutCommand} from "@aws-sdk/lib-dynamodb";
const dynamodb = DynamoDBDocumentClient.from(new DynamoDBClient({region: "us-east-2"})); */
const uniqid = require('uniqid')
const dynamodb = new AWS.DynamoDB.DocumentClient()

exports.handler = async (event) => {
  try {
    const Item = {
      UserID: 'user_' + uniqid(),
      Age: event.age,
      Height: event.height,
      Income: event.income
    }
    await dynamodb
      .put({
        TableName: 'compare-yourself',
        Item
      })
      .promise()
    return Item
  } catch (err) {
    return err
  }
}
